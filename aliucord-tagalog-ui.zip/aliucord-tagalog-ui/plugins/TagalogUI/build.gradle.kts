version = "1.0.0" // Plugin version. Increment this to trigger an update
description = "Translates common Discord menus, buttons, and labels into Tagalog."

aliucord {
    // Changelog of your plugin
    changelog.set(
        """
        # 1.0.0
        * Initial release: translates common buttons, menus, and settings labels into Tagalog.
        """.trimIndent(),
    )

    // TODO: put your own name here
    // author("YourName", 0L, hyperlink = true)

    // Excludes this plugin from publishing and global plugin repositories.
    // Set this to false if the plugin is unfinished
    deploy.set(true)
}
