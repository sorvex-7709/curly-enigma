package com.github.yourusername.tagalogui

import android.content.Context
import android.content.res.Resources
import com.aliucord.Utils
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.*
import org.json.JSONObject

/**
 * TagalogUI
 *
 * Scope, read this before you expect "the whole app":
 * This does NOT translate everything in Discord. Most of Discord's screens (chat,
 * settings pages, most buttons you tap while browsing servers) are rendered by a
 * bundled React Native/JS layer, not by plain Android string resources - and that
 * JS layer isn't reachable from a hook like this one. What this DOES reach is text
 * that passes through android.content.res.Resources.getString()/getText(), which
 * on Android commonly includes things like: notification action labels, some
 * permission/rationale text, toasts, and any native (non-RN) screens/dialogs.
 *
 * How it works:
 * - We hook Resources.getString(int) and Resources.getText(int) AFTER the original
 *   call resolves the English text.
 * - We look up that exact English text in tagalog_strings.json (case-insensitively).
 * - If there's a match, we swap in the Tagalog version. If there's no match, we
 *   change nothing - the original English text passes through untouched.
 * - Because we only ever *replace an already-resolved string*, a missing dictionary
 *   entry can never crash a screen or break layout - worst case, that one string
 *   just stays in English.
 *
 * To add more translations: edit src/main/assets/tagalog_strings.json (plain
 * "English": "Tagalog" pairs). No Kotlin knowledge needed for that part.
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class TagalogUI : Plugin() {
    private val translations = HashMap<String, String>()

    override fun load(context: Context) {
        loadTranslations(context)
    }

    override fun start(context: Context) {
        // Resources.getString(int id) -> String
        patcher.after<Resources>(
            "getString",
            Int::class.javaPrimitiveType,
        ) { param ->
            val original = param.result as? String ?: return@after
            translations[original.lowercase()]?.let { param.result = it }
        }

        // Resources.getText(int id) -> CharSequence (used by some native views)
        patcher.after<Resources>(
            "getText",
            Int::class.javaPrimitiveType,
        ) { param ->
            val original = param.result?.toString() ?: return@after
            translations[original.lowercase()]?.let { param.result = it }
        }
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }

    private fun loadTranslations(context: Context) {
        try {
            context.assets.open("tagalog_strings.json").bufferedReader().use { reader ->
                val json = JSONObject(reader.readText())
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    translations[key.lowercase()] = json.getString(key)
                }
            }
        } catch (e: Exception) {
            Utils.showToast("TagalogUI: failed to load translations - ${e.message}")
        }
    }
}
